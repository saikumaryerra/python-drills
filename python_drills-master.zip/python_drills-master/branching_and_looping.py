def integers_from_start_to_end_using_range(start, end, step):
    """return a list"""
    pass


def integers_from_start_to_end_using_while(start, end, step):
    """return a list"""
    pass


def two_digit_primes():
    """
    Return a list of all two-digit-primes
    """
    pass
