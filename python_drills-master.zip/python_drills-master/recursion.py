def html_dict_search(html_dict, selector):
    """
    Implement `id` and `class` selectors
    """
    pass
