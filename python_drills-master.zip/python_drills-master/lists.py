def sum_items_in_list(x):
    pass


def list_length(x):
    pass


def last_three_items(x):
    pass


def first_three_items(x):
    pass


def sort_list(x):
    pass


def append_item(x, item):
    pass


def remove_last_item(x):
    pass


def count_occurrences(x, item):
    pass


def is_item_present_in_list(x, item):
    pass


def append_all_items_of_y_to_x(x, y):
    """
    x and y are lists
    """
    pass


def list_copy(x):
    """
    Create a shallow copy of x
    """

